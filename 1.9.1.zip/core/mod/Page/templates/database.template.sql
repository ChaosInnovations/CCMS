INSERT INTO `content_pages` VALUES('', 'SG9tZSBQYWdl', '', 'PGRpdiBjbGFzcz0iY29udGFpbmVyIj4KICA8ZGl2IGNsYXNzPSJjYXJkIG1iLTQiPgogICAgPGgyIGNsYXNzPSJjYXJkLWhlYWRlciI+SXQgd29ya3MhPC9oMj4KICAgIDxkaXYgY2xhc3M9ImNhcmQtYm9keSI+CiAgICAgIHt7c2l0ZW1hcH19CiAgICA8L2Rpdj4KICA8L2Rpdj4KPC9kaXY+', 1, 1, 1, 0, '2019-02-26');
INSERT INTO `content_pages` VALUES('admin', 'U2VjdXJlIEFjY2VzcyBQb3J0YWw=', '', 'PGRpdiBjbGFzcz0iY29udGFpbmVyIj4KICA8ZGl2IGNsYXNzPSJjYXJkIG1iLTQiPgogICAgPGgyIGNsYXNzPSJjYXJkLWhlYWRlciI+V2VibWFzdGVyIExvZ2luPC9oMj4KICAgIDxkaXYgY2xhc3M9ImNhcmQtYm9keSI+CiAgICAgIHt7bG9naW5mb3JtfX0KICAgIDwvZGl2PgogIDwvZGl2Pgo8L2Rpdj4=', 1, 1, 1, 0, '2019-02-26');
INSERT INTO `content_pages` VALUES('_default/bottom', 'RGVmYXVsdCBCb3R0b20=', '', 'PG5hdiBjbGFzcz0ibmF2YmFyIGZpeGVkLWJvdHRvbSBuYXZiYXItbGlnaHQgYmctbGlnaHQganVzdGlmeS1jb250ZW50LWVuZCI+CiAgPGEgY2xhc3M9Im5hdmJhci1icmFuZCIgaHJlZj0iIyI+RGVmYXVsdCBQYWdlIEJvdHRvbSBTZWN0aW9uPC9hPgo8L25hdj4=', 0, 1, 0, 1, '2019-02-26');
INSERT INTO `content_pages` VALUES('_default/head', 'RGVmYXVsdCBIZWFk', 'PG1ldGEgbmFtZT0idmlld3BvcnQiIGNvbnRlbnQ9IndpZHRoPWRldmljZS13aWR0aCxpbml0aWFsLXNjYWxlPTEsbWF4aW11bS1zY2FsZT0xLHVzZXItc2NhbGFibGU9bm8iIC8+', 'VXNlIHRoaXMgX2RlZmF1bHQgcGFnZSB0byBlZGl0IHRoZSBkZWZhdWx0IDxjb2RlPiZsdDtoZWFkJmd0OzwvY29kZT4gYmxvY2su', 0, 1, 1, 1, '2019-02-26');
INSERT INTO `content_pages` VALUES('_default/notfound', 'UGFnZSBOb3QgRm91bmQ=', '', 'PGRpdiBjbGFzcz0iY29udGFpbmVyIj4KICA8ZGl2IGNsYXNzPSJjYXJkIG1iLTQiPgogICAgPGgyIGNsYXNzPSJjYXJkLWhlYWRlciI+UGFnZSBub3QgRm91bmQhPC9oMj4KICAgIDxkaXYgY2xhc3M9ImNhcmQtYm9keSI+CiAgICAgIDxwPjxhIGhyZWY9Ii97e3BhZ2VpZH19Ij4ve3twYWdlaWR9fTwvYT4gd2Fzbid0IGZvdW5kIG9uIHRoaXMgc2l0ZS48L3A+CiAgICAgIDxwPjxhIGhyZWY9Ii8iPkdvIEhvbWU8L2E+PC9wPgogICAgPC9kaXY+CiAgPC9kaXY+CjwvZGl2Pg==', 1, 1, 1, 0, '2019-02-26');
INSERT INTO `content_pages` VALUES('_default/page', 'TmV3IFBhZ2U=', '', 'PGRpdiBjbGFzcz0iY29udGFpbmVyIj4KICA8ZGl2IGNsYXNzPSJjYXJkIG1iLTQiPgogICAgPGgyIGNsYXNzPSJjYXJkLWhlYWRlciI+VGhpcyBpcyBhIG5ldyBwYWdlPC9oMj4KICAgIDxkaXYgY2xhc3M9ImNhcmQtYm9keSI+CiAgICAgIDxwPkxvcmVtIGlwc3VtIGRvbG9yIHNpdCBhbWV0LCBjb25zZWN0ZXR1ciBhZGlwaXNjaW5nIGVsaXQuIEludGVnZXIgaW4gbW9sZXN0aWUgb2Rpby4gSW50ZWdlciB2ZWwgY29tbW9kbyB0b3J0b3IuIFByb2luIHRlbXB1cyBlbGl0IHF1aXMgbGliZXJvIHZvbHV0cGF0LCBldSBzYWdpdHRpcyBuZXF1ZSBncmF2aWRhLiBEb25lYyBzZWQgbGVvIHNpdCBhbWV0IHVybmEgdWx0cmljZXMgcnV0cnVtLiBBbGlxdWFtIGRvbG9yIG51bmMsIGV1aXNtb2QgZXUgbWkgZXUsIGNvbnNlY3RldHVyIHVsdHJpY2VzIGxvcmVtLiBNYXVyaXMgdGVtcG9yIGVyb3MgdmVsIGV1aXNtb2Qgc2FnaXR0aXMuIFByYWVzZW50IHF1aXMgbWF1cmlzIGluIG5pc2kgbG9ib3J0aXMgaW50ZXJkdW0gZWdldCBldCBuaWJoLiBWZXN0aWJ1bHVtIGVnZXN0YXMgbG9yZW0gZXUgb3JjaSBjb25ndWUsIGlkIHZlc3RpYnVsdW0gc2VtIGNvbmRpbWVudHVtLiBQaGFzZWxsdXMgdnVscHV0YXRlLCBxdWFtIGluIGVsZW1lbnR1bSBjb25kaW1lbnR1bSwgcmlzdXMgdmVsaXQgcG9ydGEgZGlhbSwgaGVuZHJlcml0IGNvbnNlY3RldHVyIGVzdCBsZW8gc2l0IGFtZXQgbGFjdXMuIFZpdmFtdXMgaWQgbmlzbCBub24gYW50ZSBjb252YWxsaXMgcmhvbmN1cyBlZ2V0IGlkIG5pc2wuIEluIGhhYyBoYWJpdGFzc2UgcGxhdGVhIGRpY3R1bXN0LiBDbGFzcyBhcHRlbnQgdGFjaXRpIHNvY2lvc3F1IGFkIGxpdG9yYSB0b3JxdWVudCBwZXIgY29udWJpYSBub3N0cmEsIHBlciBpbmNlcHRvcyBoaW1lbmFlb3MuIEluIHNlZCBlbmltIGJsYW5kaXQgbmVxdWUgdGluY2lkdW50IHRlbXBvci48L3A+CiAgICA8L2Rpdj4KICA8L2Rpdj4KPC9kaXY+', 1, 1, 1, 1, '2019-02-26');
INSERT INTO `content_pages` VALUES('_default/top', 'RGVmYXVsdCBUb3A=', '', 'PG5hdiBjbGFzcz0ibmF2YmFyIG5hdmJhci1leHBhbmQtbGcgbmF2YmFyLWRhcmsgYmctcHJpbWFyeSBtYi00Ij4KICA8YSBjbGFzcz0ibmF2YmFyLWJyYW5kIiBocmVmPSIjIj5EZWZhdWx0IFBhZ2UgVG9wIFNlY3Rpb248L2E+CjwvbmF2Pg==', 0, 0, 0, 1, '2019-02-26');


/* TEMPORARY SITE CONFIGURATION DEFAULTS */
CREATE TABLE `config` (
  `property` varchar(256) NOT NULL,UNIQUE KEY `property` (`property`),
  `value` varchar(256) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `config` VALUES('creationdate', UTC_DATE);
INSERT INTO `config` VALUES('email_notifs_from', '');
INSERT INTO `config` VALUES('email_notifs_host', '');
INSERT INTO `config` VALUES('email_notifs_pass', '');
INSERT INTO `config` VALUES('email_notifs_user', '');
INSERT INTO `config` VALUES('email_primary_from', '');
INSERT INTO `config` VALUES('email_primary_host', '');
INSERT INTO `config` VALUES('email_primary_pass', '');
INSERT INTO `config` VALUES('email_primary_user', '');
INSERT INTO `config` VALUES('websitetitle', 'CCMS Test');